import org.w3c.dom.ls.LSOutput;

        public class Notlar {
        private String KullaniciAdi;
        private double Turkce;
        private double Matematik;
        private double Kimya;
        private double Fizik;
        private final double Edebiyat;
         public Notlar( String KullaniciAdi, double Turkce, double Matematik, double Kimya,double Fizik,double Edebiyat ){
        this.Turkce=Turkce;
        this.Matematik=Matematik;
        this.Kimya=Kimya;
        this.Fizik=Fizik;
        this.Edebiyat=Edebiyat;
        this.KullaniciAdi=KullaniciAdi;
    }
         public void setKullaniciAdi(double KullaniciAdi){
        Notlar notlar = this;
        KullaniciAdi=KullaniciAdi;
    }
         public void setTurkce(double Turkce){
         Notlar notlar = this;
         Turkce=Turkce;

     }
        public void setMatematik(double Matematik){
        Notlar notlar = this;
        Matematik=Matematik;

    }

         public void setKimya(double Kimya){
        Notlar notlar = this;
        Kimya=Kimya;

    }

        public void setFizik(double Fizik){
        Notlar notlar = this;
        Fizik=Fizik;

    }
        public void setEdebiyat(double Edebiyat){
        Notlar notlar = this;
        Edebiyat=Edebiyat;


        }



        public void showInfos(){
            System.out.println("kullanıcı adı:"+KullaniciAdi+">>>>>>>>>>>>>");
       if (Turkce>100 || Turkce<0 ) {
           System.out.println("TÜRKÇE NOTUNUZU HATALI GİRDİNİZ!!!  =   "+Turkce);
       }
       else {
           System.out.println("Türkçe notu:"+Turkce);
       }
       if (Matematik>100 || Matematik<0 ) {
           System.out.println("MATEMATİK NOTUNUZU HATALI GİRDİNİZ!!!   =   "+Matematik);
       }
       else {
           System.out.println("Matematik notu:"+Matematik);
       }
       if (Kimya>100 || Kimya<0 ) {
           System.out.println("KİMYA NOTUNUZU HATALI GİRDİNİZ!!!   =   "+Kimya);
       }
       else {
           System.out.println("Kimya notu:"+Kimya);
       }
       if (Fizik>100 || Fizik<0 ) {
           System.out.println("FİZİK NOTUNUZU HATALI GİRDİNİZ!!!    =   "+Fizik);
       }
       else {
           System.out.println("Fizik notu:"+Fizik);
       }

       if (Edebiyat>100 || Edebiyat<0 ) {
           System.out.println("EDEBİYAT NOTUNUZU HATALI GİRDİNİZ!!!   =   "+Edebiyat);
       }
       else {
           System.out.println("edebiyat notu:"+Edebiyat);
       }

       double YilSonu0rtalamasi=(Turkce+Kimya+Fizik+Matematik+Edebiyat)/5;



       if (YilSonu0rtalamasi>100    ||    YilSonu0rtalamasi<0){
           System.out.println("notlarınızı tekrar kontrol ediniz");
       }
       else {
           System.out.println("Yıl Sonu Ortalaması:"+YilSonu0rtalamasi);
       }
       if (YilSonu0rtalamasi<=100 && YilSonu0rtalamasi>=85 ){
           System.out.println("TAKDİR BELGESİ ALABİLİYORSUNUZ");
       } else if (YilSonu0rtalamasi<85 && YilSonu0rtalamasi>=70 ) {
           System.out.println("TEŞEKKÜR BELGESİ ALABİLİYORSUNUZ");
       } else if (YilSonu0rtalamasi<70 && YilSonu0rtalamasi>=0 ) {
           System.out.println("BİR BELGE ALAMIYORSUNUZ");
       }





        }
       }




